'USE Strict';
const bcrypt = require('bcrypt')
const { Controller } = require('egg');
const BaseHandler = require('../libs/base')

const RestController = require('./rest')

class RestUserController extends RestController {
  constructor(ctx) {
    super(ctx, 'User')
  }

  /**
   * 新增模板页面表单
   */
  async new() {
    const { ctx,app } = this;
    let  context = { 
      title: '新增用户'
     }
    await ctx.render('user/new.njk', context);
    
  }

  /**
   * 编辑表单页面
   */
  async edit() {
    let  context = { 
      opt: 0,
      title: '',           
      users: []
   }
    const { ctx, app } = this;
    const { type, id } = {...ctx.params, ...ctx.query} 
    const users =  await ctx.model.User.findById(BaseHandler.toInt(id));
    context.opt = type
    context.users.push(users)
    await ctx.render('user/edit.njk', context);
    
  }

  

  async index() {
    const { ctx } = this; 
    let { pageSize,curPage } = {...ctx.params, ...ctx.query} 
    let context = { 
      totalCount: 0,
      title: '',           
      users: []
    }
    if(!pageSize && !curPage)
    {
      await ctx.render('user/index.njk', context);
      return
    }
    console.log('pageSize,curPage===>',pageSize,curPage)

    if(!pageSize) pageSize = 10;
    if(!curPage) curPage = 1;
    
    //
    //const users =  await ctx.model.User.findAll({attributes:{ exclude: ['created_at','updated_at'] }});
    // const users =  await ctx.model.User.findAll({});
    const users =  await ctx.model.User.findAndCountAll({
      attributes:{ exclude: ['password'] },
      offset: (curPage - 1)* pageSize,    
      limit: pageSize,      
      order: [ ['id', 'DESC'] ]
    });    
    
    context.title = '用户列表';
    context.users = users.rows;
    context.totalCount = users.count;    
    // await ctx.render('user/index.njk', context);
    
     const data =context
     const success_message = ""
     
     BaseHandler.resSuccess(ctx, data, success_message)
  }
    
}

module.exports = RestUserController;
