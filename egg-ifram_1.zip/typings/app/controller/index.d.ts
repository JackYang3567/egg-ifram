// This file is created by egg-ts-helper@1.25.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/controller/admin');
import ExportBase = require('../../../app/controller/base');
import ExportHome = require('../../../app/controller/home');
import ExportRest = require('../../../app/controller/rest');
import ExportRestUser = require('../../../app/controller/restUser');
import ExportUser = require('../../../app/controller/user');
import ExportUtils = require('../../../app/controller/utils');

declare module 'egg' {
  interface IController {
    admin: ExportAdmin;
    base: ExportBase;
    home: ExportHome;
    rest: ExportRest;
    restUser: ExportRestUser;
    user: ExportUser;
    utils: ExportUtils;
  }
}
