// This file is created by egg-ts-helper@1.25.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuth = require('../../../app/middleware/auth');
import ExportCheckCaptcha = require('../../../app/middleware/checkCaptcha');

declare module 'egg' {
  interface IMiddleware {
    auth: typeof ExportAuth;
    checkCaptcha: typeof ExportCheckCaptcha;
  }
}
